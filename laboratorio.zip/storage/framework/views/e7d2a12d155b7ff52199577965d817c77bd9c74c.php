<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card-header font-weight-bold bg-primary">Ver resultados</div>
            <br><br>
            <h3><?php echo e($file->description); ?></h3>
            <p>
                <iframe width="100%" height="1000" src="<?php echo e(asset('storage/'.$file->name)); ?>"></iframe>
            </p>
            <a href="<?php echo e(route('files.index', $file->user_id)); ?>">
                <button class="btn btn-primary">
                    <?php echo e(__('Regresar')); ?>

                </button>
            </a>
        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laboratorio\resources\views/files/ShowFile.blade.php ENDPATH**/ ?>