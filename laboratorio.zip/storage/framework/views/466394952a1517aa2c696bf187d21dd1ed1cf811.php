<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header font-weight-bold bg-primary">Información del usuario</div>
                <div class="card-body">
                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control " disabled
                               name="name" value="<?php echo e($user->name); ?>" autocomplete="name" autofocus>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="price" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Correo')); ?></label>

                    <div class="col-md-6">
                        <input id="email" type="text" class="form-control " disabled
                               name="email" value="<?php echo e($user->email); ?>" autocomplete="email" autofocus>
                    </div>
                </div>

                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <a href="<?php echo e(url('/home')); ?>">
                            <button class="btn btn-primary">
                                <?php echo e(__('Regresar')); ?>

                            </button>
                        </a>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laboratorio\resources\views/users/ShowUser.blade.php ENDPATH**/ ?>