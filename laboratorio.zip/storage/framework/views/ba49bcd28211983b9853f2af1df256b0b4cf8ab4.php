<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card-header font-weight-bold bg-primary">Añadir resultados</div>
            <form method="post" action="<?php echo e(route('file.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <br>
                <div class="form-group row">
                    <label for="description" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Descripción')); ?></label>

                    <div class="col-md-3">
                        <input id="description" type="text" class="form-control " required
                               name="description" value="<?php echo e(old('description')); ?>" autocomplete="description" autofocus>
                    </div>
                    <label for="file" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Resultados')); ?></label>

                    <div class="col-md-3">
                        <input id="name" type="file" class="form-control" required
                               name="name" value="<?php echo e(old('name')); ?>" autocomplete="name" autofocus>
                    </div>
                </div>
                <input id="id" type="text" class="form-control " required
                       name="id" value="<?php echo e($id); ?>" hidden autofocus>
                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-success">
                            <?php echo e(__('Guardar')); ?>

                        </button>
                    </div>
                </div>
            </form>
            <a href="<?php echo e(route('files.index', $id)); ?>">
                <button class="btn btn-primary">
                    <?php echo e(__('Regresar')); ?>

                </button>
            </a>
        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laboratorio\resources\views/files/CreateFile.blade.php ENDPATH**/ ?>