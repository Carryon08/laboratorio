<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header bg-primary">Resultados de usuario</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <a class="btn btn-success btn-elevate btn-circle btn-icon float-right" title="Añadir archivo"
                       href="<?php echo e(route('files.create', $id)); ?>">
                        Añadir resultados
                    </a>
                    <br><br>
                    <table class="table table-primary">
                        <thead>
                        <tr class="d-flex">
                            <th class="col-6">Tipo de resultado</th>
                            <th class="col-6">Opciones</th>
                        </tr>
                        </thead>
                        <?php $__currentLoopData = $UserFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                        <tr class="d-flex">
                            <td class="col-6"><?php echo e($file->description); ?></td>
                            <td class="col-6">
                                <div class="row">
                                    <a class="btn btn-primary btn-elevate btn-circle btn-icon" title="Ver"
                                       href="<?php echo e(route('file.show',$file->id)); ?>">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    &nbsp;
                                    <a class="btn btn-warning btn-circle btn-icon" title="Descargar"
                                       href="<?php echo e(route('files.download',$file->name)); ?>">
                                        <i class="fa fa-download"></i>
                                    </a>
                                    &nbsp;
                                    <form method="post" action="<?php echo e(route('file.destroy', $file->id)); ?>"
                                          enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-circle btn-icon"
                                                title="Borrar">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                    &nbsp;
                                </div>
                            </td>
                        </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laboratorio\resources\views/files/IndexFiles.blade.php ENDPATH**/ ?>