<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header bg-primary">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-primary">
                        <thead>
                            <tr class="d-flex">
                                <th class="col-4">Nombre</th>
                                <th class="col-4">Correo</th>
                                <th class="col-4">Opciones</th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                        <tr class="d-flex">
                            <td class="col-4"><?php echo e($user->name); ?></td>
                            <td class="col-4"><?php echo e($user->email); ?></td>
                            <td class="col-4">
                                <div class="row">
                                <a class="btn btn-primary btn-elevate btn-circle btn-icon" title="Ver"
                                   href="<?php echo e(route('user.show', $user->id)); ?>">
                                    <i class="fa fa-eye"></i>
                                </a>
                                    &nbsp;
                                <a class="btn btn-warning btn-circle btn-icon" title="Editar"
                                   href="<?php echo e(route('user.edit', $user->id)); ?>">
                                    <i class="fa fa-pencil"></i>
                                </a>
                                    &nbsp;
                                <form method="post" action="<?php echo e(route('user.destroy', $user->id)); ?>"
                                      enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-circle btn-icon"
                                            title="Borrar">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                                    &nbsp;
                                <a class="btn btn-secondary btn-circle btn-icon" title="Resultados"
                                   href="<?php echo e(route('files.index', $user->id)); ?>">
                                    <i class="fa fa-id-card"></i>
                                </a>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laboratorio\resources\views/home.blade.php ENDPATH**/ ?>